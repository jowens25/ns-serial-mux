#!/bin/bash

# Build source package for PPA upload
dpkg-buildpackage -S -sa -us -uc

mv ../*.dsc ../*.tar.* ../*.buildinfo ../*.changes dist/

debsign -k ABF8C9E8DF6D4AFD02BA58DCBA050865951ED7DD dist/ns-serial-mux_1.0.15_source.changes
