# Novus Power Products
stdio uart <-> unix sockets