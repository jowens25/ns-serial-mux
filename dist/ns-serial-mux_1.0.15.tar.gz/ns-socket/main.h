#include <stdint.h>
#include <string.h>
#include <stdio.h>
extern int attempts;


#define CONFIG_FILE "/etc/ns/ns-serial-mux.conf"

char* rtrim(char* string);
char* ltrim(char *string); 